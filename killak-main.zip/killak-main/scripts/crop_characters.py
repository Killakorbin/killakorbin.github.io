#!/usr/bin/env python3
"""
Script to crop individual character portraits from ABA roster screenshots.
Analyzes the grid layout and extracts each character.
"""
from PIL import Image
import os

OUTPUT_DIR = "/app/frontend/public/characters/cropped"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Character data based on the roster images
# Format: (roster_file, row_y_start, row_y_end, characters_list_with_x_positions)

# Roster 1: One Piece, Dragon Ball Z, Naruto, Bleach, MISC
ROSTER1_CHARS = {
    "One Piece": {
        "y_range": (52, 145),
        "chars": ["Sanji", "Zoro", "Gear 5", "Franky", "Jinbe", "Chopper", "Usopp", "Nami", "Robin", "Brook", "Hancock", "Akainu", "Law", "Sabo", "Ace", "Doflamingo", "Katakuri", "Whitebeard"]
    },
    "Dragon Ball Z": {
        "y_range": (157, 250),
        "chars": ["Piccolo", "Goku", "SSJ3 Goku", "Vegeta", "SSJ Vegeta", "Trunks", "Gohan", "Teen Gohan", "Broly", "Cell", "Frieza", "Hit", "Beerus", "Jiren", "Gogeta", "Vegito", "Goku Black"]
    },
    "Naruto": {
        "y_range": (262, 355),
        "chars": ["Naruto", "Kakashi", "Itachi", "Sasuke", "Minato", "Madara", "Guy", "Gaara", "Pain", "Obito", "Orochimaru", "Hashirama", "Tobirama"]
    },
    "Bleach": {
        "y_range": (367, 460),
        "chars": ["Ichigo", "Byakuya", "Ulquiorra", "Aizen", "Yoruichi", "Toshiro", "Kenpachi", "Yamamoto", "Grimmjow", "Rukia", "Gin", "Urahara", "Vasto Lorde", "Starrk", "Shunsui", "Unohana", "Uryu"]
    },
    "MISC": {
        "y_range": (476, 555),
        "chars": ["Giorno", "DIO", "Jotaro", "Gon", "Killua", "Hisoka", "Kurapika", "Meruem", "Yusuke", "Guts", "Griffith", "Levi", "Eren", "Saitama"]
    }
}

# Roster 2: JoJo, Hunter x Hunter, Jujutsu Kaisen, MHA, Fate  
ROSTER2_CHARS = {
    "JoJo": {
        "y_range": (10, 105),
        "chars": ["Jotaro", "DIO", "Josuke", "Kira", "Giorno", "Diavolo", "Jonathan", "Pucci", "Jolyne", "Weather Report", "Johnny", "Gyro", "Valentine"]
    },
    "Hunter x Hunter": {
        "y_range": (117, 210),
        "chars": ["Gon", "Killua", "Kurapika", "Leorio", "Hisoka", "Chrollo", "Meruem", "Pitou"]
    },
    "Jujutsu Kaisen": {
        "y_range": (222, 315),
        "chars": ["Itadori", "Sukuna", "Gojo", "Megumi", "Nobara", "Todo", "Maki"]
    },
    "MHA": {
        "y_range": (327, 420),
        "chars": ["Deku", "All Might", "Bakugo", "Todoroki", "Endeavor", "Shigaraki", "Dabi"]
    },
    "Fate": {
        "y_range": (432, 520),
        "chars": ["Saber", "Archer", "Lancer", "Rider", "Gilgamesh", "Berserker"]
    }
}

# Roster 3: Fairy Tail, One Punch Man, Chainsaw Man, Metal Gear, Demon Slayer, SAO, Prestige, Legacy
ROSTER3_CHARS = {
    "Fairy Tail": {
        "y_range": (10, 105),
        "x_start": 115,
        "chars": ["Natsu", "Gray"]
    },
    "One Punch Man": {
        "y_range": (10, 105),
        "x_start": 875,
        "chars": ["Saitama", "Genos", "Garou"]
    },
    "Chainsaw Man": {
        "y_range": (117, 210),
        "x_start": 115,
        "chars": ["Denji", "Power", "Makima"]
    },
    "Metal Gear": {
        "y_range": (117, 210),
        "x_start": 875,
        "chars": ["Snake", "Raiden", "Armstrong"]
    },
    "Demon Slayer": {
        "y_range": (225, 318),
        "x_start": 115,
        "chars": ["Tanjiro", "Zenitsu", "Inosuke"]
    },
    "Anime?": {
        "y_range": (225, 318),
        "x_start": 875,
        "chars": ["Mob", "???"]
    },
    "SAO": {
        "y_range": (333, 426),
        "x_start": 115,
        "chars": ["Kirito", "Asuna"]
    },
    "Prestige": {
        "y_range": (450, 545),
        "x_start": 115,
        "chars": ["P. Goku", "P. Broly", "P. Naruto", "P. Madara", "P. Ichigo", "P. Aizen", "P. Jotaro", "P. DIO", "P. Itadori"]
    },
    "Legacy": {
        "y_range": (450, 545),
        "x_start": 875,
        "chars": ["L. Vegeta", "L. Sasuke"]
    }
}

def crop_row(img, y_start, y_end, x_start, num_chars, char_width=55, gap=3, series_name="", char_names=None):
    """Crop characters from a row"""
    cropped = []
    for i in range(num_chars):
        x = x_start + i * (char_width + gap)
        box = (x, y_start, x + char_width, y_end)
        try:
            char_img = img.crop(box)
            name = char_names[i] if char_names and i < len(char_names) else f"char_{i}"
            cropped.append((name, char_img))
        except Exception as e:
            print(f"Error cropping {series_name} char {i}: {e}")
    return cropped

def process_roster1():
    img = Image.open("/app/frontend/public/characters/roster1.png")
    all_chars = []
    
    # One Piece - starts after the logo
    y1, y2 = 52, 145
    chars = ROSTER1_CHARS["One Piece"]["chars"]
    x_start = 115
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_").replace(".", "")
        char_img.save(f"{OUTPUT_DIR}/onepiece_{safe_name}.png")
        all_chars.append(("One Piece", name, f"/characters/cropped/onepiece_{safe_name}.png"))
    
    # Dragon Ball Z
    y1, y2 = 157, 250
    chars = ROSTER1_CHARS["Dragon Ball Z"]["chars"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_").replace(".", "")
        char_img.save(f"{OUTPUT_DIR}/dbz_{safe_name}.png")
        all_chars.append(("Dragon Ball Z", name, f"/characters/cropped/dbz_{safe_name}.png"))
    
    # Naruto
    y1, y2 = 262, 355
    chars = ROSTER1_CHARS["Naruto"]["chars"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_").replace(".", "")
        char_img.save(f"{OUTPUT_DIR}/naruto_{safe_name}.png")
        all_chars.append(("Naruto", name, f"/characters/cropped/naruto_{safe_name}.png"))
    
    # Bleach
    y1, y2 = 367, 460
    chars = ROSTER1_CHARS["Bleach"]["chars"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_").replace(".", "")
        char_img.save(f"{OUTPUT_DIR}/bleach_{safe_name}.png")
        all_chars.append(("Bleach", name, f"/characters/cropped/bleach_{safe_name}.png"))
    
    # MISC
    y1, y2 = 476, 555
    chars = ROSTER1_CHARS["MISC"]["chars"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_").replace(".", "")
        char_img.save(f"{OUTPUT_DIR}/misc_{safe_name}.png")
        all_chars.append(("MISC", name, f"/characters/cropped/misc_{safe_name}.png"))
    
    return all_chars

def process_roster2():
    img = Image.open("/app/frontend/public/characters/roster2.png")
    all_chars = []
    x_start = 115
    
    # JoJo
    y1, y2 = 10, 105
    chars = ROSTER2_CHARS["JoJo"]["chars"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_").replace(".", "")
        char_img.save(f"{OUTPUT_DIR}/jojo_{safe_name}.png")
        all_chars.append(("JoJo", name, f"/characters/cropped/jojo_{safe_name}.png"))
    
    # Hunter x Hunter
    y1, y2 = 117, 210
    chars = ROSTER2_CHARS["Hunter x Hunter"]["chars"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_").replace(".", "")
        char_img.save(f"{OUTPUT_DIR}/hxh_{safe_name}.png")
        all_chars.append(("Hunter x Hunter", name, f"/characters/cropped/hxh_{safe_name}.png"))
    
    # Jujutsu Kaisen
    y1, y2 = 222, 315
    chars = ROSTER2_CHARS["Jujutsu Kaisen"]["chars"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_").replace(".", "")
        char_img.save(f"{OUTPUT_DIR}/jjk_{safe_name}.png")
        all_chars.append(("Jujutsu Kaisen", name, f"/characters/cropped/jjk_{safe_name}.png"))
    
    # MHA
    y1, y2 = 327, 420
    chars = ROSTER2_CHARS["MHA"]["chars"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_").replace(".", "")
        char_img.save(f"{OUTPUT_DIR}/mha_{safe_name}.png")
        all_chars.append(("MHA", name, f"/characters/cropped/mha_{safe_name}.png"))
    
    # Fate
    y1, y2 = 432, 520
    chars = ROSTER2_CHARS["Fate"]["chars"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_").replace(".", "")
        char_img.save(f"{OUTPUT_DIR}/fate_{safe_name}.png")
        all_chars.append(("Fate", name, f"/characters/cropped/fate_{safe_name}.png"))
    
    return all_chars

def process_roster3():
    img = Image.open("/app/frontend/public/characters/roster3.png")
    all_chars = []
    
    # Fairy Tail (left side)
    y1, y2 = 10, 105
    x_start = 115
    chars = ["Natsu", "Gray"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_")
        char_img.save(f"{OUTPUT_DIR}/fairytail_{safe_name}.png")
        all_chars.append(("Fairy Tail", name, f"/characters/cropped/fairytail_{safe_name}.png"))
    
    # One Punch Man (right side)
    x_start = 875
    chars = ["Saitama", "Genos", "Garou"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_")
        char_img.save(f"{OUTPUT_DIR}/opm_{safe_name}.png")
        all_chars.append(("One Punch Man", name, f"/characters/cropped/opm_{safe_name}.png"))
    
    # Chainsaw Man (left)
    y1, y2 = 117, 210
    x_start = 115
    chars = ["Denji", "Power", "Makima"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_")
        char_img.save(f"{OUTPUT_DIR}/csm_{safe_name}.png")
        all_chars.append(("Chainsaw Man", name, f"/characters/cropped/csm_{safe_name}.png"))
    
    # Metal Gear (right)
    x_start = 875
    chars = ["Snake", "Raiden", "Armstrong"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_")
        char_img.save(f"{OUTPUT_DIR}/metalgear_{safe_name}.png")
        all_chars.append(("Metal Gear", name, f"/characters/cropped/metalgear_{safe_name}.png"))
    
    # Demon Slayer (left)
    y1, y2 = 225, 318
    x_start = 115
    chars = ["Tanjiro", "Zenitsu", "Inosuke"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_")
        char_img.save(f"{OUTPUT_DIR}/demonslayer_{safe_name}.png")
        all_chars.append(("Demon Slayer", name, f"/characters/cropped/demonslayer_{safe_name}.png"))
    
    # Mob Psycho / Other (right)
    x_start = 875
    chars = ["Mob", "Saitama2"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_")
        char_img.save(f"{OUTPUT_DIR}/other_{safe_name}.png")
        all_chars.append(("Other", name, f"/characters/cropped/other_{safe_name}.png"))
    
    # SAO (left)
    y1, y2 = 333, 426
    x_start = 115
    chars = ["Kirito", "Asuna"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_")
        char_img.save(f"{OUTPUT_DIR}/sao_{safe_name}.png")
        all_chars.append(("SAO", name, f"/characters/cropped/sao_{safe_name}.png"))
    
    # Prestige (left)
    y1, y2 = 450, 545
    x_start = 115
    chars = ["P_Goku", "P_Broly", "P_Naruto", "P_Madara", "P_Ichigo", "P_Aizen", "P_Jotaro", "P_DIO", "P_Itadori"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_")
        char_img.save(f"{OUTPUT_DIR}/prestige_{safe_name}.png")
        all_chars.append(("Prestige", name.replace("P_", ""), f"/characters/cropped/prestige_{safe_name}.png"))
    
    # Legacy (right)
    x_start = 875
    chars = ["L_Vegeta", "L_Sasuke"]
    for i, name in enumerate(chars):
        x = x_start + i * 58
        box = (x, y1, x + 55, y2)
        char_img = img.crop(box)
        safe_name = name.lower().replace(" ", "_")
        char_img.save(f"{OUTPUT_DIR}/legacy_{safe_name}.png")
        all_chars.append(("Legacy", name.replace("L_", ""), f"/characters/cropped/legacy_{safe_name}.png"))
    
    return all_chars

if __name__ == "__main__":
    print("Processing roster 1...")
    chars1 = process_roster1()
    print(f"Cropped {len(chars1)} characters from roster 1")
    
    print("Processing roster 2...")
    chars2 = process_roster2()
    print(f"Cropped {len(chars2)} characters from roster 2")
    
    print("Processing roster 3...")
    chars3 = process_roster3()
    print(f"Cropped {len(chars3)} characters from roster 3")
    
    all_chars = chars1 + chars2 + chars3
    print(f"\nTotal characters: {len(all_chars)}")
    
    # Generate Python dict for backend
    print("\n# Character data for backend:")
    by_series = {}
    for series, name, path in all_chars:
        if series not in by_series:
            by_series[series] = []
        safe_id = name.lower().replace(" ", "_").replace(".", "")
        by_series[series].append({"id": safe_id, "name": name, "image": path})
    
    for series, chars in by_series.items():
        print(f'    "{series}": {chars},')
