import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "../components/ui/input";
import { toast } from "sonner";
import axios from "axios";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function HomePage() {
  const navigate = useNavigate();
  const [joinCode, setJoinCode] = useState("");
  const [isJoining, setIsJoining] = useState(false);

  const handleJoinLobby = async () => {
    if (!joinCode.trim()) {
      toast.error("Please enter a lobby code");
      return;
    }

    setIsJoining(true);
    try {
      const response = await axios.get(`${API}/lobbies/${joinCode.toUpperCase()}`);
      if (response.data) {
        navigate(`/lobby/${joinCode.toUpperCase()}`);
      }
    } catch (error) {
      toast.error("Lobby not found. Check the code and try again.");
    } finally {
      setIsJoining(false);
    }
  };

  return (
    <div className="aba-background">
      <div className="min-h-screen flex flex-col">
        {/* Top Banner */}
        <header className="aba-banner py-4 px-6" data-testid="header-banner">
          <div className="max-w-7xl mx-auto flex justify-center">
            <img
              src="https://customer-assets.emergentagent.com/job_aba-draft-lobby/artifacts/0p6ds86l_6d0f119b-a98f-41c7-9e05-251af4da485f.png"
              alt="KOS Draft"
              className="h-16 md:h-24"
              data-testid="kos-logo"
            />
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 flex items-center justify-center p-6">
          <div className="w-full max-w-lg">
            {/* Title */}
            <div className="text-center mb-12">
              <h1 
                className="font-heading text-5xl md:text-6xl text-white tracking-tight mb-2"
                data-testid="main-title"
              >
                DRAFT LOBBY
              </h1>
              <p className="text-zinc-400 text-lg">
                Create or join a 4v4 character draft
              </p>
            </div>

            {/* Action Buttons */}
            <div className="space-y-6">
              {/* Create Lobby Button */}
              <button
                onClick={() => navigate("/create")}
                className="aba-btn aba-btn-green w-full text-2xl py-4"
                data-testid="create-lobby-btn"
              >
                CREATE LOBBY
              </button>

              {/* Divider */}
              <div className="flex items-center gap-4">
                <div className="flex-1 h-px bg-zinc-700"></div>
                <span className="text-zinc-500 font-heading text-xl">OR</span>
                <div className="flex-1 h-px bg-zinc-700"></div>
              </div>

              {/* Join Lobby Section */}
              <div className="bg-black/80 p-6 rounded-lg border border-zinc-700">
                <label className="block font-heading text-xl text-white mb-3">
                  JOIN LOBBY
                </label>
                <div className="flex gap-3">
                  <Input
                    type="text"
                    placeholder="Enter lobby code"
                    value={joinCode}
                    onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                    onKeyDown={(e) => e.key === "Enter" && handleJoinLobby()}
                    className="aba-input flex-1 uppercase text-lg"
                    maxLength={6}
                    data-testid="join-code-input"
                  />
                  <button
                    onClick={handleJoinLobby}
                    disabled={isJoining}
                    className="aba-btn aba-btn-blue px-8"
                    data-testid="join-lobby-btn"
                  >
                    {isJoining ? "..." : "JOIN"}
                  </button>
                </div>
              </div>
            </div>

            {/* Info */}
            <div className="mt-12 text-center">
              <p className="text-zinc-500 text-sm">
                Draft order: Ban &rarr; Ban &rarr; Pick 1 &rarr; Pick 2 &rarr; Ban &rarr; Ban &rarr; Pick 2 &rarr; Pick 2 &rarr; Pick 1
              </p>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
