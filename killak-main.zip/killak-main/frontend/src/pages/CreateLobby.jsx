import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "../components/ui/input";
import { toast } from "sonner";
import axios from "axios";
import { ArrowLeft, Copy, Check } from "lucide-react";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function CreateLobby() {
  const navigate = useNavigate();
  const [isCreating, setIsCreating] = useState(false);
  const [team1Name, setTeam1Name] = useState("Team 1");
  const [team2Name, setTeam2Name] = useState("Team 2");
  const [lobbyCode, setLobbyCode] = useState(null);
  const [copied, setCopied] = useState(false);

  const handleCreateLobby = async () => {
    if (!team1Name.trim() || !team2Name.trim()) {
      toast.error("Please enter team names");
      return;
    }

    setIsCreating(true);
    try {
      const response = await axios.post(`${API}/lobbies`, {
        team1_name: team1Name,
        team2_name: team2Name,
      });

      setLobbyCode(response.data.code);
      toast.success("Lobby created! Share the code with players.");
    } catch (error) {
      toast.error("Failed to create lobby");
      console.error(error);
    } finally {
      setIsCreating(false);
    }
  };

  const copyCode = async () => {
    const link = `${window.location.origin}/lobby/${lobbyCode}`;
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      toast.success("Link copied!");
    } catch (err) {
      const textArea = document.createElement("textarea");
      textArea.value = link;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand("copy");
      document.body.removeChild(textArea);
      setCopied(true);
      toast.success("Link copied!");
    }
    setTimeout(() => setCopied(false), 2000);
  };

  const goToLobby = () => {
    navigate(`/lobby/${lobbyCode}`);
  };

  return (
    <div className="aba-background">
      <div className="min-h-screen flex flex-col">
        {/* Top Banner */}
        <header className="aba-banner py-4 px-6">
          <div className="max-w-7xl mx-auto flex items-center gap-6">
            <button
              onClick={() => navigate("/")}
              className="text-zinc-400 hover:text-white transition-colors flex items-center gap-2"
              data-testid="back-btn"
            >
              <ArrowLeft size={24} />
              <span className="font-heading text-xl">BACK</span>
            </button>
            <div className="flex-1 flex justify-center">
              <img
                src="https://customer-assets.emergentagent.com/job_aba-draft-lobby/artifacts/0p6ds86l_6d0f119b-a98f-41c7-9e05-251af4da485f.png"
                alt="KOS Draft"
                className="h-12 md:h-16"
              />
            </div>
            <div className="w-24"></div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 p-6 flex items-center justify-center">
          <div className="w-full max-w-xl">
            {!lobbyCode ? (
              // Step 1: Create lobby with team names
              <>
                <h1 className="font-heading text-4xl md:text-5xl text-white text-center mb-8" data-testid="create-title">
                  CREATE LOBBY
                </h1>

                <div className="bg-black/80 p-6 rounded-lg border border-zinc-700 space-y-6">
                  <div>
                    <label className="block font-heading text-lg text-blue-400 mb-2">
                      TEAM 1 NAME
                    </label>
                    <Input
                      type="text"
                      value={team1Name}
                      onChange={(e) => setTeam1Name(e.target.value)}
                      className="aba-input w-full text-lg"
                      placeholder="Enter team name"
                      data-testid="team1-name-input"
                    />
                  </div>

                  <div>
                    <label className="block font-heading text-lg text-red-400 mb-2">
                      TEAM 2 NAME
                    </label>
                    <Input
                      type="text"
                      value={team2Name}
                      onChange={(e) => setTeam2Name(e.target.value)}
                      className="aba-input w-full text-lg"
                      placeholder="Enter team name"
                      data-testid="team2-name-input"
                    />
                  </div>

                  <button
                    onClick={handleCreateLobby}
                    disabled={isCreating}
                    className="aba-btn aba-btn-green w-full text-xl py-4"
                    data-testid="submit-create-btn"
                  >
                    {isCreating ? "CREATING..." : "CREATE LOBBY"}
                  </button>
                </div>

                <p className="mt-6 text-center text-zinc-500 text-sm">
                  After creating, share the lobby code with players to join.
                </p>
              </>
            ) : (
              // Step 2: Show lobby code
              <>
                <h1 className="font-heading text-4xl md:text-5xl text-white text-center mb-8" data-testid="lobby-created-title">
                  LOBBY CREATED!
                </h1>

                <div className="bg-black/80 p-8 rounded-lg border border-zinc-700 text-center">
                  <p className="text-zinc-400 mb-4">Share this code with players:</p>
                  
                  <div className="flex items-center justify-center gap-4 mb-6">
                    <span 
                      className="font-heading text-5xl text-yellow-400 tracking-widest"
                      data-testid="lobby-code-display"
                    >
                      {lobbyCode}
                    </span>
                    <button
                      onClick={copyCode}
                      className="p-3 bg-zinc-800 hover:bg-zinc-700 rounded transition-colors"
                      data-testid="copy-code-btn"
                    >
                      {copied ? (
                        <Check size={24} className="text-green-400" />
                      ) : (
                        <Copy size={24} className="text-zinc-400" />
                      )}
                    </button>
                  </div>

                  <p className="text-zinc-500 text-sm mb-6">
                    Players can join at the home page using this code, or use the direct link.
                  </p>

                  <button
                    onClick={goToLobby}
                    className="aba-btn aba-btn-blue text-xl px-8 py-3"
                    data-testid="go-to-lobby-btn"
                  >
                    GO TO LOBBY
                  </button>
                </div>

                <div className="mt-6 text-center">
                  <button
                    onClick={() => {
                      setLobbyCode(null);
                      setTeam1Name("Team 1");
                      setTeam2Name("Team 2");
                    }}
                    className="text-zinc-500 hover:text-white transition-colors"
                    data-testid="create-another-btn"
                  >
                    Create another lobby
                  </button>
                </div>
              </>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
