import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import axios from "axios";
import { ArrowLeft, Copy, RotateCcw, Check, Users, Play, Search, Volume2, VolumeX } from "lucide-react";
import { ScrollArea } from "../components/ui/scroll-area";
import { Input } from "../components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "../components/ui/dialog";
import { playSound, preloadSounds, setSoundEnabled, isSoundEnabled } from "../lib/sounds";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;
const WS_URL = BACKEND_URL.replace(/^http/, "ws") + "/api/ws";

const DRAFT_PHASES = [
  { phase: 0, action: "ban", team: 1, label: "Team 1 Ban" },
  { phase: 1, action: "ban", team: 2, label: "Team 2 Ban" },
  { phase: 2, action: "ban", team: 1, label: "Team 1 Ban" },
  { phase: 3, action: "ban", team: 2, label: "Team 2 Ban" },
  { phase: 4, action: "pick", team: 1, label: "Team 1 Pick" },
  { phase: 5, action: "pick", team: 2, label: "Team 2 Pick" },
  { phase: 6, action: "ban", team: 1, label: "Team 1 Ban" },
  { phase: 7, action: "ban", team: 2, label: "Team 2 Ban" },
  { phase: 8, action: "ban", team: 1, label: "Team 1 Ban" },
  { phase: 9, action: "ban", team: 2, label: "Team 2 Ban" },
  { phase: 10, action: "pick", team: 1, label: "Team 1 Pick" },
  { phase: 11, action: "pick", team: 2, label: "Team 2 Pick" },
  { phase: 12, action: "pick", team: 1, label: "Team 1 Pick" },
  { phase: 13, action: "pick", team: 2, label: "Team 2 Pick" },
  { phase: 14, action: "pick", team: 1, label: "Team 1 Pick" },
  { phase: 15, action: "pick", team: 2, label: "Team 2 Pick" },
];

export default function DraftRoom() {
  const { code } = useParams();
  const navigate = useNavigate();
  const [lobby, setLobby] = useState(null);
  const [characters, setCharacters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [soundOn, setSoundOn] = useState(true);

  const [showJoinDialog, setShowJoinDialog] = useState(false);
  const [displayName, setDisplayName] = useState("");
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [isJoining, setIsJoining] = useState(false);
  const [currentPlayer, setCurrentPlayer] = useState(null);

  const wsRef = useRef(null);
  const reconnectTimer = useRef(null);
  const prevPhaseRef = useRef(null);
  const prevStatusRef = useRef(null);

  // Preload sounds on mount
  useEffect(() => {
    preloadSounds();
  }, []);

  // Play sounds on lobby state changes (via WebSocket or polling)
  useEffect(() => {
    if (!lobby) return;
    const prevPhase = prevPhaseRef.current;
    const prevStatus = prevStatusRef.current;
    prevPhaseRef.current = lobby.current_phase;
    prevStatusRef.current = lobby.status;

    if (prevPhase === null || prevStatus === null) return;

    if (prevStatus === "waiting" && lobby.status === "drafting") {
      playSound("draftStart", 0.4);
      return;
    }
    if (lobby.status === "complete" && prevStatus !== "complete") {
      playSound("draftComplete", 0.4);
      return;
    }
    if (lobby.status === "waiting" && prevStatus !== "waiting") {
      return; // reset
    }
    if (lobby.current_phase !== prevPhase && lobby.status === "drafting") {
      const prevAction = DRAFT_PHASES[prevPhase]?.action;
      const currAction = DRAFT_PHASES[lobby.current_phase]?.action;
      if (prevAction === "ban" && currAction === "pick") {
        playSound("banToPickTransition", 0.3);
      } else if (prevAction === "pick" && currAction === "ban") {
        playSound("pickToBanTransition", 0.3);
      } else if (prevAction === "ban") {
        playSound("ban", 0.5);
      } else if (prevAction === "pick") {
        playSound("pick", 0.5);
      }
    }
  }, [lobby?.current_phase, lobby?.status]);

  const fetchLobby = useCallback(async () => {
    try {
      const response = await axios.get(`${API}/lobbies/${code}`);
      setLobby(response.data);
      return response.data;
    } catch (error) {
      toast.error("Failed to load lobby");
      navigate("/");
      return null;
    }
  }, [code, navigate]);

  const fetchCharacters = async () => {
    try {
      const response = await axios.get(`${API}/characters`);
      setCharacters(response.data);
    } catch (error) {
      console.error("Failed to load characters", error);
    }
  };

  // WebSocket connection
  const connectWebSocket = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    const ws = new WebSocket(`${WS_URL}/${code}`);
    wsRef.current = ws;

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.lobby) {
          setLobby(data.lobby);
        }
      } catch (e) {
        console.error("WS parse error", e);
      }
    };

    ws.onclose = () => {
      wsRef.current = null;
      reconnectTimer.current = setTimeout(connectWebSocket, 3000);
    };

    ws.onerror = () => {
      ws.close();
    };
  }, [code]);

  useEffect(() => {
    const init = async () => {
      const [lobbyData] = await Promise.all([fetchLobby(), fetchCharacters()]);
      setLoading(false);

      const savedPlayer = sessionStorage.getItem(`lobby_${code}_player`);
      if (savedPlayer) {
        setCurrentPlayer(savedPlayer);
      } else if (lobbyData && lobbyData.status === "waiting") {
        setShowJoinDialog(true);
      }
    };
    init();
    connectWebSocket();

    // Fallback polling every 5s in case WebSocket drops
    const interval = setInterval(() => {
      if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
        fetchLobby();
      }
    }, 5000);

    return () => {
      clearInterval(interval);
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      if (wsRef.current) wsRef.current.close();
    };
  }, [fetchLobby, code, connectWebSocket]);

  const handleJoinLobby = async () => {
    if (!displayName.trim()) {
      toast.error("Please enter a display name");
      return;
    }
    if (!selectedTeam) {
      toast.error("Please select a team");
      return;
    }
    setIsJoining(true);
    try {
      const response = await axios.post(`${API}/lobbies/${code}/join`, {
        display_name: displayName.trim(),
        team: selectedTeam,
      });
      setLobby(response.data);
      setCurrentPlayer(displayName.trim());
      sessionStorage.setItem(`lobby_${code}_player`, displayName.trim());
      setShowJoinDialog(false);
      toast.success(`Joined ${selectedTeam === 1 ? lobby.team1_name : lobby.team2_name}!`);
    } catch (error) {
      toast.error(error.response?.data?.detail || "Failed to join lobby");
    } finally {
      setIsJoining(false);
    }
  };

  const handleStartDraft = async () => {
    try {
      const response = await axios.post(`${API}/lobbies/${code}/start`);
      setLobby(response.data);
      toast.success("Draft started!");
    } catch (error) {
      toast.error(error.response?.data?.detail || "Failed to start draft");
    }
  };

  const getCurrentPhaseInfo = () => {
    if (!lobby || lobby.status !== "drafting") return null;
    return DRAFT_PHASES[lobby.current_phase] || null;
  };

  const handleCharacterClick = async (charId) => {
    if (!lobby || lobby.status !== "drafting") return;
    const allSelected = [
      ...lobby.team1_picks, ...lobby.team2_picks,
      ...lobby.team1_bans, ...lobby.team2_bans,
    ];
    if (allSelected.includes(charId)) {
      toast.error("Character already selected");
      return;
    }
    const phaseInfo = getCurrentPhaseInfo();
    if (!phaseInfo) return;

    playSound("gridClick", 0.3);

    try {
      const response = await axios.post(`${API}/lobbies/${code}/action`, {
        character_id: charId,
        action_type: phaseInfo.action,
      });
      setLobby(response.data);
      if (response.data.status === "complete") {
        toast.success("Draft complete!");
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || "Action failed");
    }
  };

  const handleReset = async () => {
    try {
      const response = await axios.post(`${API}/lobbies/${code}/reset`);
      setLobby(response.data);
      toast.success("Draft reset!");
    } catch (error) {
      toast.error("Failed to reset draft");
    }
  };

  const copyLobbyCode = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      toast.success("Link copied!");
    } catch (err) {
      const textArea = document.createElement("textarea");
      textArea.value = window.location.href;
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand("copy");
        setCopied(true);
        toast.success("Link copied!");
      } catch (e) {
        toast.error("Failed to copy link");
      }
      document.body.removeChild(textArea);
    }
    setTimeout(() => setCopied(false), 2000);
  };

  const getCharacterName = (charId) => {
    for (const series of characters) {
      const char = series.characters.find((c) => c.id === charId);
      if (char) return char.name;
    }
    return charId;
  };

  const isCharacterBanned = (charId) => {
    if (!lobby) return false;
    return [...lobby.team1_bans, ...lobby.team2_bans].includes(charId);
  };

  const isCharacterPicked = (charId) => {
    if (!lobby) return false;
    return [...lobby.team1_picks, ...lobby.team2_picks].includes(charId);
  };

  const isCharacterSelected = (charId) => {
    return isCharacterBanned(charId) || isCharacterPicked(charId);
  };

  const toggleSound = () => {
    const newState = !soundOn;
    setSoundOn(newState);
    setSoundEnabled(newState);
  };

  // Filter characters by search query
  const filteredCharacters = useMemo(() => {
    if (!searchQuery.trim()) return characters;
    const query = searchQuery.toLowerCase().trim();
    return characters
      .map((series) => ({
        ...series,
        characters: series.characters.filter((c) =>
          c.name.toLowerCase().includes(query) || c.id.toLowerCase().includes(query)
        ),
      }))
      .filter((series) => series.characters.length > 0);
  }, [characters, searchQuery]);

  if (loading) {
    return (
      <div className="aba-background min-h-screen flex items-center justify-center">
        <div className="text-white font-heading text-3xl">LOADING...</div>
      </div>
    );
  }

  if (!lobby) return null;

  const phaseInfo = getCurrentPhaseInfo();
  const totalPlayers = lobby.team1_players.length + lobby.team2_players.length;
  const canStartDraft = totalPlayers >= 2;

  return (
    <div className="aba-background">
      <div className="min-h-screen flex flex-col">
        {/* Join Dialog */}
        <Dialog open={showJoinDialog} onOpenChange={setShowJoinDialog}>
          <DialogContent className="bg-zinc-900 border-zinc-700 text-white max-w-md">
            <DialogHeader>
              <DialogTitle className="font-heading text-2xl text-center">
                JOIN LOBBY
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-6 py-4">
              <div>
                <label className="block text-sm text-zinc-400 mb-2">Your Display Name</label>
                <Input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Enter your name"
                  className="aba-input"
                  maxLength={20}
                  data-testid="join-display-name-input"
                />
              </div>
              <div>
                <label className="block text-sm text-zinc-400 mb-3">Choose Your Team</label>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => setSelectedTeam(1)}
                    disabled={lobby.team1_players.length >= 4}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      selectedTeam === 1
                        ? "border-blue-500 bg-blue-500/20"
                        : "border-zinc-700 hover:border-blue-400"
                    } ${lobby.team1_players.length >= 4 ? "opacity-50 cursor-not-allowed" : ""}`}
                    data-testid="select-team1-btn"
                  >
                    <div className="font-heading text-xl text-blue-400">{lobby.team1_name}</div>
                    <div className="text-sm text-zinc-500 mt-1">{lobby.team1_players.length}/4 players</div>
                  </button>
                  <button
                    onClick={() => setSelectedTeam(2)}
                    disabled={lobby.team2_players.length >= 4}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      selectedTeam === 2
                        ? "border-red-500 bg-red-500/20"
                        : "border-zinc-700 hover:border-red-400"
                    } ${lobby.team2_players.length >= 4 ? "opacity-50 cursor-not-allowed" : ""}`}
                    data-testid="select-team2-btn"
                  >
                    <div className="font-heading text-xl text-red-400">{lobby.team2_name}</div>
                    <div className="text-sm text-zinc-500 mt-1">{lobby.team2_players.length}/4 players</div>
                  </button>
                </div>
              </div>
              <button
                onClick={handleJoinLobby}
                disabled={isJoining || !displayName.trim() || !selectedTeam}
                className="aba-btn aba-btn-green w-full"
                data-testid="confirm-join-btn"
              >
                {isJoining ? "JOINING..." : "JOIN LOBBY"}
              </button>
              <button
                onClick={() => setShowJoinDialog(false)}
                className="w-full text-zinc-500 hover:text-white text-sm"
              >
                Spectate instead
              </button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Top Banner */}
        <header className="aba-banner py-3 px-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate("/")}
                className="text-zinc-400 hover:text-white transition-colors flex items-center gap-2"
                data-testid="back-btn"
              >
                <ArrowLeft size={20} />
                <span className="font-heading text-lg hidden sm:inline">BACK</span>
              </button>
              <button
                onClick={toggleSound}
                className="p-2 bg-zinc-800 hover:bg-zinc-700 rounded transition-colors"
                data-testid="sound-toggle-btn"
                title={soundOn ? "Mute sounds" : "Unmute sounds"}
              >
                {soundOn ? (
                  <Volume2 size={18} className="text-yellow-400" />
                ) : (
                  <VolumeX size={18} className="text-zinc-500" />
                )}
              </button>
            </div>

            <div className="flex items-center gap-4">
              <span className="font-heading text-xl text-yellow-400" data-testid="lobby-code">
                CODE: {lobby.code}
              </span>
              <button
                onClick={copyLobbyCode}
                className="p-2 bg-zinc-800 hover:bg-zinc-700 rounded transition-colors"
                data-testid="copy-link-btn"
              >
                {copied ? <Check size={18} className="text-green-400" /> : <Copy size={18} className="text-zinc-400" />}
              </button>
            </div>

            <button
              onClick={handleReset}
              className="text-zinc-400 hover:text-white transition-colors flex items-center gap-2"
              data-testid="reset-btn"
            >
              <RotateCcw size={20} />
              <span className="font-heading text-lg hidden sm:inline">RESET</span>
            </button>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 p-4 overflow-hidden">
          <div className="h-full max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-[280px_1fr_280px] gap-4">
            {/* Team 1 Panel */}
            <div className="team-panel team1 p-4 rounded-lg" data-testid="team1-draft-panel">
              <h2 className="font-heading text-2xl text-blue-400 mb-2 text-center">{lobby.team1_name}</h2>
              <div className="mb-4">
                <div className="flex items-center gap-2 text-zinc-500 text-sm mb-2">
                  <Users size={14} />
                  <span>Players ({lobby.team1_players.length}/4)</span>
                </div>
                <div className="space-y-1">
                  {lobby.team1_players.map((player, i) => (
                    <div key={i} className="text-sm text-white bg-blue-900/30 px-2 py-1 rounded">{player}</div>
                  ))}
                  {Array.from({ length: 4 - lobby.team1_players.length }).map((_, i) => (
                    <div key={`empty-${i}`} className="text-sm text-zinc-600 border border-dashed border-zinc-700 px-2 py-1 rounded">Waiting...</div>
                  ))}
                </div>
              </div>
              <div className="mb-4">
                <h3 className="font-heading text-sm text-zinc-500 mb-2">BANS</h3>
                <div className="grid grid-cols-2 gap-2">
                  {[0, 1, 2, 3].map((i) => (
                    <div key={i} className={`card-slot rounded flex items-center justify-center ${lobby.team1_bans[i] ? "filled ban" : ""}`} data-testid={`team1-ban-${i}`}>
                      {lobby.team1_bans[i] && (
                        <span className="text-xs text-red-400 font-heading text-center px-1">{getCharacterName(lobby.team1_bans[i])}</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-heading text-sm text-zinc-500 mb-2">PICKS</h3>
                <div className="grid grid-cols-2 gap-2">
                  {[0, 1, 2, 3].map((i) => (
                    <div key={i} className={`card-slot rounded flex flex-col items-center justify-center p-2 ${lobby.team1_picks[i] ? "filled pick" : ""}`} data-testid={`team1-pick-${i}`}>
                      {lobby.team1_picks[i] && (
                        <>
                          <span className="text-xs text-green-400 font-heading text-center">{getCharacterName(lobby.team1_picks[i])}</span>
                          {lobby.team1_players[i] && <span className="text-xs text-zinc-500 mt-1">{lobby.team1_players[i]}</span>}
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Center - Character Grid */}
            <div className="flex flex-col min-h-0">
              {/* Status Indicator */}
              <div className="mb-3 text-center">
                {lobby.status === "waiting" ? (
                  <div className="space-y-3">
                    <div className="inline-block bg-yellow-600 px-6 py-3 rounded-lg" data-testid="waiting-indicator">
                      <span className="font-heading text-xl text-white">WAITING FOR PLAYERS ({totalPlayers}/8)</span>
                    </div>
                    {canStartDraft && (
                      <div>
                        <button onClick={handleStartDraft} className="aba-btn aba-btn-green px-8" data-testid="start-draft-btn">
                          <Play size={20} className="inline mr-2" />START DRAFT
                        </button>
                      </div>
                    )}
                    {!currentPlayer && (
                      <div>
                        <button onClick={() => setShowJoinDialog(true)} className="aba-btn aba-btn-blue px-8" data-testid="open-join-dialog-btn">JOIN LOBBY</button>
                      </div>
                    )}
                  </div>
                ) : lobby.status === "complete" ? (
                  <div className="inline-block bg-green-600 px-6 py-3 rounded-lg" data-testid="draft-complete">
                    <span className="font-heading text-2xl text-white">DRAFT COMPLETE</span>
                  </div>
                ) : phaseInfo ? (
                  <div
                    className={`inline-block px-6 py-3 rounded-lg pulse-glow ${
                      phaseInfo.team === 1 ? "bg-blue-600 text-blue-200" : "bg-red-600 text-red-200"
                    }`}
                    data-testid="phase-indicator"
                  >
                    <span className="font-heading text-xl">
                      {phaseInfo.action === "ban" ? "BAN" : "PICK"} - {phaseInfo.team === 1 ? lobby.team1_name : lobby.team2_name}
                    </span>
                  </div>
                ) : null}
              </div>

              {/* Search Bar */}
              <div className="mb-3 relative">
                <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 pointer-events-none" />
                <Input
                  type="text"
                  placeholder="Search characters..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="aba-input pl-10 w-full"
                  data-testid="character-search-input"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white text-sm"
                    data-testid="clear-search-btn"
                  >
                    CLEAR
                  </button>
                )}
              </div>

              {/* Character Roster */}
              <ScrollArea className="flex-1 roster-container rounded-lg p-4">
                <div className="space-y-6">
                  {filteredCharacters.length === 0 && searchQuery && (
                    <div className="text-center py-8 text-zinc-500 font-heading text-lg" data-testid="no-results">
                      NO CHARACTERS FOUND FOR "{searchQuery.toUpperCase()}"
                    </div>
                  )}
                  {filteredCharacters.map((series) => (
                    <div key={series.series} data-testid={`series-${series.series.toLowerCase().replace(/\s+/g, "-")}`}>
                      <div className="series-header px-3 py-1 mb-3 rounded flex items-center gap-3">
                        <h3 className="text-white text-lg">{series.series}</h3>
                        <span className="text-zinc-500 text-sm">({series.characters.length})</span>
                      </div>
                      <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-8 gap-2">
                        {series.characters.map((char) => {
                          const isBanned = isCharacterBanned(char.id);
                          const isPicked = isCharacterPicked(char.id);
                          const isSelected = isCharacterSelected(char.id);
                          const isDisabled = isSelected || lobby.status !== "drafting";

                          return (
                            <button
                              key={char.id}
                              onClick={() => !isDisabled && handleCharacterClick(char.id)}
                              disabled={isDisabled}
                              className={`character-card relative overflow-hidden flex items-center justify-center p-2 ${
                                isBanned ? "banned" : ""
                              } ${isPicked ? "picked" : ""} ${isDisabled ? "disabled" : ""}`}
                              data-testid={`char-${char.id}`}
                            >
                              <span className="font-heading text-sm text-white text-center leading-tight">{char.name}</span>
                              {isBanned && (
                                <div className="absolute inset-0 flex items-center justify-center bg-black/70">
                                  <span className="text-red-500 font-heading text-sm rotate-[-15deg]">BANNED</span>
                                </div>
                              )}
                              {isPicked && (
                                <div className="absolute inset-0 flex items-center justify-center bg-black/70">
                                  <span className="text-green-500 font-heading text-sm">PICKED</span>
                                </div>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>

            {/* Team 2 Panel */}
            <div className="team-panel team2 p-4 rounded-lg" data-testid="team2-draft-panel">
              <h2 className="font-heading text-2xl text-red-400 mb-2 text-center">{lobby.team2_name}</h2>
              <div className="mb-4">
                <div className="flex items-center gap-2 text-zinc-500 text-sm mb-2">
                  <Users size={14} />
                  <span>Players ({lobby.team2_players.length}/4)</span>
                </div>
                <div className="space-y-1">
                  {lobby.team2_players.map((player, i) => (
                    <div key={i} className="text-sm text-white bg-red-900/30 px-2 py-1 rounded">{player}</div>
                  ))}
                  {Array.from({ length: 4 - lobby.team2_players.length }).map((_, i) => (
                    <div key={`empty-${i}`} className="text-sm text-zinc-600 border border-dashed border-zinc-700 px-2 py-1 rounded">Waiting...</div>
                  ))}
                </div>
              </div>
              <div className="mb-4">
                <h3 className="font-heading text-sm text-zinc-500 mb-2">BANS</h3>
                <div className="grid grid-cols-2 gap-2">
                  {[0, 1, 2, 3].map((i) => (
                    <div key={i} className={`card-slot rounded flex items-center justify-center ${lobby.team2_bans[i] ? "filled ban" : ""}`} data-testid={`team2-ban-${i}`}>
                      {lobby.team2_bans[i] && (
                        <span className="text-xs text-red-400 font-heading text-center px-1">{getCharacterName(lobby.team2_bans[i])}</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-heading text-sm text-zinc-500 mb-2">PICKS</h3>
                <div className="grid grid-cols-2 gap-2">
                  {[0, 1, 2, 3].map((i) => (
                    <div key={i} className={`card-slot rounded flex flex-col items-center justify-center p-2 ${lobby.team2_picks[i] ? "filled pick" : ""}`} data-testid={`team2-pick-${i}`}>
                      {lobby.team2_picks[i] && (
                        <>
                          <span className="text-xs text-green-400 font-heading text-center">{getCharacterName(lobby.team2_picks[i])}</span>
                          {lobby.team2_players[i] && <span className="text-xs text-zinc-500 mt-1">{lobby.team2_players[i]}</span>}
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
