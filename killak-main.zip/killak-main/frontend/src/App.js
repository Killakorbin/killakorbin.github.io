import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import CreateLobby from "./pages/CreateLobby";
import DraftRoom from "./pages/DraftRoom";
import { Toaster } from "./components/ui/sonner";

function App() {
  return (
    <div className="App min-h-screen">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/create" element={<CreateLobby />} />
          <Route path="/lobby/:code" element={<DraftRoom />} />
        </Routes>
      </BrowserRouter>
      <Toaster position="top-center" />
    </div>
  );
}

export default App;
