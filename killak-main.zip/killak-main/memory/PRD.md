# KOS Draft Lobby - Product Requirements Document

## Original Problem Statement
Build a website for creating draft lobbies (4v4) where the creator sets team display names, and players can join via code, enter a display name, and choose their team. The draft system has a specific flow (2 bans, 2 bans, pick, pick, 2 bans, 2 bans, remaining picks). The character roster is based on the Anime Battle Arena (ABA) Wiki. Theme uses "KOS" logo, character cards are TEXT-ONLY (no images). LoL champion select sounds for drafting.

## Architecture
- **Frontend**: React with TailwindCSS, Shadcn/UI components
- **Backend**: FastAPI with MongoDB (lobbies stored in DB)
- **Real-time**: WebSocket (FastAPI native) with polling fallback
- **Audio**: League of Legends champion select sounds via CommunityDragon CDN

## Core Features Implemented
- [x] Home page with KOS logo and Create/Join lobby options
- [x] Lobby creation with custom team names
- [x] 6-character shareable lobby codes
- [x] Join lobby via code with display name and team selection
- [x] Full 16-phase draft system (ban -> ban -> pick -> ban -> ban -> remaining picks)
- [x] Complete ABA character roster: 196 characters across 20 series/categories
- [x] Text-only character cards (no images) with high contrast
- [x] Ban/pick overlays on selected characters
- [x] Draft reset functionality
- [x] Copy lobby link feature
- [x] **Character search/filter** — Real-time filtering across all 196 chars and 20 rosters
- [x] **Real-time WebSocket sync** — Instant updates for all players in a lobby (with 5s polling fallback)
- [x] **League of Legends draft sounds** — Ban, pick, phase transition, draft start/complete sounds from CommunityDragon CDN with mute toggle

## Character Roster (Feb 2026)
- One Piece (22), Dragon Ball (21), Naruto (20), Bleach (17)
- JoJo (18), Hunter x Hunter (10), Jujutsu Kaisen (9), My Hero Academia (9)
- Fate (10), Fairy Tail (3), Chainsaw Man (3), Demon Slayer (5), SAO (3)
- One Punch Man (3), Metal Gear (3)
- Miscellaneous (21), Project Moon (2), Prestige (9), Legacy (3), Others (5)
- **Total: 196 characters across 20 rosters**

## API Endpoints
- `GET /api/characters` - Get all ABA characters by series
- `POST /api/lobbies` - Create new lobby
- `GET /api/lobbies/{code}` - Get lobby by code
- `POST /api/lobbies/{code}/join` - Join lobby with display name + team
- `POST /api/lobbies/{code}/start` - Start the draft
- `POST /api/lobbies/{code}/action` - Execute pick/ban action
- `POST /api/lobbies/{code}/reset` - Reset draft
- `GET /api/draft-phases` - Get draft phase definitions
- `WS /api/ws/{code}` - WebSocket for real-time lobby sync

## Key Files
- `/app/backend/server.py` - All backend logic, WebSocket, character data
- `/app/frontend/src/pages/DraftRoom.jsx` - Draft room with search, WebSocket, sounds
- `/app/frontend/src/lib/sounds.js` - LoL sound effects module (CommunityDragon CDN)
- `/app/frontend/src/pages/HomePage.jsx` - KOS-branded home page
- `/app/frontend/src/pages/CreateLobby.jsx` - Lobby creation

## Remaining Backlog
- [ ] Spectator mode (P1)
- [ ] Draft timer option (P2)
- [ ] Draft history/replay (P2)
