"""
ABA Draft Lobby API Tests
Tests all endpoints: characters, lobbies CRUD, join, start, action, reset
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestHealthAndCharacters:
    """Test basic API health and character roster endpoints"""
    
    def test_api_root(self):
        """Test API root endpoint"""
        response = requests.get(f"{BASE_URL}/api/")
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        print(f"✓ API root returns: {data['message']}")
    
    def test_get_characters_returns_all_rosters(self):
        """Test GET /api/characters returns all 20 roster categories"""
        response = requests.get(f"{BASE_URL}/api/characters")
        assert response.status_code == 200
        data = response.json()
        
        # Should have 20 roster categories
        assert len(data) == 20, f"Expected 20 rosters, got {len(data)}"
        
        # Extract series names
        series_names = [roster['series'] for roster in data]
        print(f"✓ Found {len(data)} roster categories: {series_names}")
        
        # Verify expected categories exist
        expected_categories = [
            "One Piece", "Dragon Ball", "Naruto", "Bleach", "JoJo",
            "Hunter x Hunter", "Jujutsu Kaisen", "My Hero Academia", "Fate",
            "Fairy Tail", "Chainsaw Man", "Demon Slayer", "SAO", "One Punch Man",
            "Metal Gear", "Miscellaneous", "Project Moon", "Prestige", "Legacy", "Others"
        ]
        
        for category in expected_categories:
            assert category in series_names, f"Missing category: {category}"
        
        print(f"✓ All 20 expected categories present")
    
    def test_miscellaneous_roster_characters(self):
        """Test Miscellaneous roster has all 21 expected characters"""
        response = requests.get(f"{BASE_URL}/api/characters")
        assert response.status_code == 200
        data = response.json()
        
        misc_roster = next((r for r in data if r['series'] == 'Miscellaneous'), None)
        assert misc_roster is not None, "Miscellaneous roster not found"
        
        misc_chars = [c['name'] for c in misc_roster['characters']]
        expected_misc = [
            "Rikka Takanashi", "Kazuma Sato", "Afro Samurai", "Chika Fujiwara",
            "Wei Wuxian", "Ryuko Matoi", "Guts", "Asta", "Hiei", "Yusuke Urameshi",
            "Accelerator", "Misaka Mikoto", "Ogun Montgomery", "Sung Jin Woo", "Mob",
            "Akira Fudo", "Ragna", "Maka & Soul", "Alucard", "Edward Elric", "Satsuki Kiryuin"
        ]
        
        assert len(misc_roster['characters']) == 21, f"Expected 21 Misc chars, got {len(misc_roster['characters'])}"
        
        for char in expected_misc:
            assert char in misc_chars, f"Missing Miscellaneous character: {char}"
        
        print(f"✓ Miscellaneous roster has all 21 characters: {misc_chars}")
    
    def test_new_roster_categories(self):
        """Test new roster categories: Project Moon, Prestige, Legacy, Others"""
        response = requests.get(f"{BASE_URL}/api/characters")
        assert response.status_code == 200
        data = response.json()
        
        # Project Moon - 2 characters
        pm_roster = next((r for r in data if r['series'] == 'Project Moon'), None)
        assert pm_roster is not None, "Project Moon roster not found"
        assert len(pm_roster['characters']) == 2, f"Expected 2 Project Moon chars, got {len(pm_roster['characters'])}"
        pm_names = [c['name'] for c in pm_roster['characters']]
        assert "Roland" in pm_names and "Ricardo" in pm_names
        print(f"✓ Project Moon: {pm_names}")
        
        # Prestige - 9 characters
        prestige_roster = next((r for r in data if r['series'] == 'Prestige'), None)
        assert prestige_roster is not None, "Prestige roster not found"
        assert len(prestige_roster['characters']) == 9, f"Expected 9 Prestige chars, got {len(prestige_roster['characters'])}"
        print(f"✓ Prestige: {[c['name'] for c in prestige_roster['characters']]}")
        
        # Legacy - 3 characters
        legacy_roster = next((r for r in data if r['series'] == 'Legacy'), None)
        assert legacy_roster is not None, "Legacy roster not found"
        assert len(legacy_roster['characters']) == 3, f"Expected 3 Legacy chars, got {len(legacy_roster['characters'])}"
        print(f"✓ Legacy: {[c['name'] for c in legacy_roster['characters']]}")
        
        # Others - 5 characters
        others_roster = next((r for r in data if r['series'] == 'Others'), None)
        assert others_roster is not None, "Others roster not found"
        assert len(others_roster['characters']) == 5, f"Expected 5 Others chars, got {len(others_roster['characters'])}"
        print(f"✓ Others: {[c['name'] for c in others_roster['characters']]}")
    
    def test_total_character_count(self):
        """Test total character count is approximately 196"""
        response = requests.get(f"{BASE_URL}/api/characters")
        assert response.status_code == 200
        data = response.json()
        
        total_chars = sum(len(roster['characters']) for roster in data)
        print(f"✓ Total characters: {total_chars}")
        
        # Should be around 196 characters
        assert total_chars >= 190, f"Expected ~196 characters, got {total_chars}"


class TestLobbyCreation:
    """Test lobby creation and retrieval"""
    
    def test_create_lobby_returns_6_char_code(self):
        """Test POST /api/lobbies creates lobby with 6-char code"""
        response = requests.post(f"{BASE_URL}/api/lobbies", json={
            "team1_name": "TEST_Team_Alpha",
            "team2_name": "TEST_Team_Beta"
        })
        assert response.status_code == 200
        data = response.json()
        
        # Verify response structure
        assert "code" in data
        assert "id" in data
        assert len(data['code']) == 6, f"Expected 6-char code, got {len(data['code'])}"
        assert data['team1_name'] == "TEST_Team_Alpha"
        assert data['team2_name'] == "TEST_Team_Beta"
        assert data['status'] == "waiting"
        assert data['current_phase'] == 0
        assert data['team1_picks'] == []
        assert data['team2_picks'] == []
        assert data['team1_bans'] == []
        assert data['team2_bans'] == []
        
        print(f"✓ Created lobby with code: {data['code']}")
        return data['code']
    
    def test_get_lobby_by_code(self):
        """Test GET /api/lobbies/{code} retrieves lobby correctly"""
        # First create a lobby
        create_response = requests.post(f"{BASE_URL}/api/lobbies", json={
            "team1_name": "TEST_GetLobby_Team1",
            "team2_name": "TEST_GetLobby_Team2"
        })
        assert create_response.status_code == 200
        code = create_response.json()['code']
        
        # Then retrieve it
        get_response = requests.get(f"{BASE_URL}/api/lobbies/{code}")
        assert get_response.status_code == 200
        data = get_response.json()
        
        assert data['code'] == code
        assert data['team1_name'] == "TEST_GetLobby_Team1"
        assert data['team2_name'] == "TEST_GetLobby_Team2"
        print(f"✓ Retrieved lobby {code} successfully")
    
    def test_get_nonexistent_lobby_returns_404(self):
        """Test GET /api/lobbies/{code} returns 404 for invalid code"""
        response = requests.get(f"{BASE_URL}/api/lobbies/XXXXXX")
        assert response.status_code == 404
        print("✓ Nonexistent lobby returns 404")


class TestLobbyJoin:
    """Test joining lobbies"""
    
    def test_join_team1(self):
        """Test POST /api/lobbies/{code}/join for team 1"""
        # Create lobby
        create_response = requests.post(f"{BASE_URL}/api/lobbies", json={
            "team1_name": "TEST_JoinTeam1",
            "team2_name": "TEST_JoinTeam2"
        })
        code = create_response.json()['code']
        
        # Join team 1
        join_response = requests.post(f"{BASE_URL}/api/lobbies/{code}/join", json={
            "display_name": "TEST_Player1",
            "team": 1
        })
        assert join_response.status_code == 200
        data = join_response.json()
        
        assert "TEST_Player1" in data['team1_players']
        assert len(data['team1_players']) == 1
        print(f"✓ Joined team 1 in lobby {code}")
    
    def test_join_team2(self):
        """Test POST /api/lobbies/{code}/join for team 2"""
        # Create lobby
        create_response = requests.post(f"{BASE_URL}/api/lobbies", json={
            "team1_name": "TEST_JoinT2_Team1",
            "team2_name": "TEST_JoinT2_Team2"
        })
        code = create_response.json()['code']
        
        # Join team 2
        join_response = requests.post(f"{BASE_URL}/api/lobbies/{code}/join", json={
            "display_name": "TEST_Player2",
            "team": 2
        })
        assert join_response.status_code == 200
        data = join_response.json()
        
        assert "TEST_Player2" in data['team2_players']
        print(f"✓ Joined team 2 in lobby {code}")
    
    def test_join_duplicate_name_rejected(self):
        """Test duplicate display names are rejected"""
        # Create lobby
        create_response = requests.post(f"{BASE_URL}/api/lobbies", json={
            "team1_name": "TEST_DupName_Team1",
            "team2_name": "TEST_DupName_Team2"
        })
        code = create_response.json()['code']
        
        # Join with name
        requests.post(f"{BASE_URL}/api/lobbies/{code}/join", json={
            "display_name": "TEST_DuplicateName",
            "team": 1
        })
        
        # Try to join with same name
        dup_response = requests.post(f"{BASE_URL}/api/lobbies/{code}/join", json={
            "display_name": "TEST_DuplicateName",
            "team": 2
        })
        assert dup_response.status_code == 400
        print("✓ Duplicate display name rejected")


class TestDraftFlow:
    """Test complete draft flow through all 16 phases"""
    
    def test_start_draft(self):
        """Test POST /api/lobbies/{code}/start"""
        # Create and populate lobby
        create_response = requests.post(f"{BASE_URL}/api/lobbies", json={
            "team1_name": "TEST_StartDraft_T1",
            "team2_name": "TEST_StartDraft_T2"
        })
        code = create_response.json()['code']
        
        # Start draft
        start_response = requests.post(f"{BASE_URL}/api/lobbies/{code}/start")
        assert start_response.status_code == 200
        data = start_response.json()
        
        assert data['status'] == "drafting"
        print(f"✓ Started draft in lobby {code}")
    
    def test_ban_action_phase_0(self):
        """Test ban action in phase 0 (Team 1 ban)"""
        # Create and start lobby
        create_response = requests.post(f"{BASE_URL}/api/lobbies", json={
            "team1_name": "TEST_Ban_T1",
            "team2_name": "TEST_Ban_T2"
        })
        code = create_response.json()['code']
        requests.post(f"{BASE_URL}/api/lobbies/{code}/start")
        
        # Ban a character (phase 0 = Team 1 ban)
        action_response = requests.post(f"{BASE_URL}/api/lobbies/{code}/action", json={
            "character_id": "luffy_pts",
            "action_type": "ban"
        })
        assert action_response.status_code == 200
        data = action_response.json()
        
        assert "luffy_pts" in data['team1_bans']
        assert data['current_phase'] == 1
        print(f"✓ Ban action successful, phase advanced to {data['current_phase']}")
    
    def test_complete_draft_all_16_phases(self):
        """Test complete draft through all 16 phases"""
        # Create and start lobby
        create_response = requests.post(f"{BASE_URL}/api/lobbies", json={
            "team1_name": "TEST_FullDraft_T1",
            "team2_name": "TEST_FullDraft_T2"
        })
        code = create_response.json()['code']
        requests.post(f"{BASE_URL}/api/lobbies/{code}/start")
        
        # Get characters for selection
        chars_response = requests.get(f"{BASE_URL}/api/characters")
        all_chars = []
        for roster in chars_response.json():
            all_chars.extend([c['id'] for c in roster['characters']])
        
        # Draft phases: 0-3 bans, 4-5 picks, 6-9 bans, 10-15 picks
        draft_sequence = [
            # Phase 0-3: First ban round
            {"action": "ban", "phase": 0},
            {"action": "ban", "phase": 1},
            {"action": "ban", "phase": 2},
            {"action": "ban", "phase": 3},
            # Phase 4-5: First pick round
            {"action": "pick", "phase": 4},
            {"action": "pick", "phase": 5},
            # Phase 6-9: Second ban round
            {"action": "ban", "phase": 6},
            {"action": "ban", "phase": 7},
            {"action": "ban", "phase": 8},
            {"action": "ban", "phase": 9},
            # Phase 10-15: Remaining picks
            {"action": "pick", "phase": 10},
            {"action": "pick", "phase": 11},
            {"action": "pick", "phase": 12},
            {"action": "pick", "phase": 13},
            {"action": "pick", "phase": 14},
            {"action": "pick", "phase": 15},
        ]
        
        char_index = 0
        for i, phase_info in enumerate(draft_sequence):
            action_response = requests.post(f"{BASE_URL}/api/lobbies/{code}/action", json={
                "character_id": all_chars[char_index],
                "action_type": phase_info['action']
            })
            assert action_response.status_code == 200, f"Phase {i} failed: {action_response.text}"
            data = action_response.json()
            
            if i < 15:
                assert data['current_phase'] == i + 1, f"Expected phase {i+1}, got {data['current_phase']}"
            
            char_index += 1
            print(f"  Phase {i}: {phase_info['action']} - OK")
        
        # Verify draft is complete
        final_response = requests.get(f"{BASE_URL}/api/lobbies/{code}")
        final_data = final_response.json()
        
        assert final_data['status'] == "complete"
        assert len(final_data['team1_bans']) == 4
        assert len(final_data['team2_bans']) == 4
        assert len(final_data['team1_picks']) == 4
        assert len(final_data['team2_picks']) == 4
        
        print(f"✓ Complete draft finished - Team1 bans: {final_data['team1_bans']}, picks: {final_data['team1_picks']}")
        print(f"  Team2 bans: {final_data['team2_bans']}, picks: {final_data['team2_picks']}")
    
    def test_wrong_action_type_rejected(self):
        """Test wrong action type is rejected"""
        # Create and start lobby
        create_response = requests.post(f"{BASE_URL}/api/lobbies", json={
            "team1_name": "TEST_WrongAction_T1",
            "team2_name": "TEST_WrongAction_T2"
        })
        code = create_response.json()['code']
        requests.post(f"{BASE_URL}/api/lobbies/{code}/start")
        
        # Try to pick when should ban (phase 0)
        action_response = requests.post(f"{BASE_URL}/api/lobbies/{code}/action", json={
            "character_id": "goku_namek",
            "action_type": "pick"
        })
        assert action_response.status_code == 400
        print("✓ Wrong action type rejected")
    
    def test_duplicate_character_selection_rejected(self):
        """Test selecting already selected character is rejected"""
        # Create and start lobby
        create_response = requests.post(f"{BASE_URL}/api/lobbies", json={
            "team1_name": "TEST_DupChar_T1",
            "team2_name": "TEST_DupChar_T2"
        })
        code = create_response.json()['code']
        requests.post(f"{BASE_URL}/api/lobbies/{code}/start")
        
        # Ban a character
        requests.post(f"{BASE_URL}/api/lobbies/{code}/action", json={
            "character_id": "ichigo",
            "action_type": "ban"
        })
        
        # Try to ban same character again
        dup_response = requests.post(f"{BASE_URL}/api/lobbies/{code}/action", json={
            "character_id": "ichigo",
            "action_type": "ban"
        })
        assert dup_response.status_code == 400
        print("✓ Duplicate character selection rejected")


class TestDraftReset:
    """Test draft reset functionality"""
    
    def test_reset_draft(self):
        """Test POST /api/lobbies/{code}/reset"""
        # Create, start, and make some actions
        create_response = requests.post(f"{BASE_URL}/api/lobbies", json={
            "team1_name": "TEST_Reset_T1",
            "team2_name": "TEST_Reset_T2"
        })
        code = create_response.json()['code']
        requests.post(f"{BASE_URL}/api/lobbies/{code}/start")
        
        # Make a ban
        requests.post(f"{BASE_URL}/api/lobbies/{code}/action", json={
            "character_id": "naruto_p1",
            "action_type": "ban"
        })
        
        # Reset
        reset_response = requests.post(f"{BASE_URL}/api/lobbies/{code}/reset")
        assert reset_response.status_code == 200
        data = reset_response.json()
        
        assert data['status'] == "waiting"
        assert data['current_phase'] == 0
        assert data['team1_bans'] == []
        assert data['team2_bans'] == []
        assert data['team1_picks'] == []
        assert data['team2_picks'] == []
        
        print(f"✓ Draft reset successful in lobby {code}")


class TestDraftPhases:
    """Test draft phases endpoint"""
    
    def test_get_draft_phases(self):
        """Test GET /api/draft-phases returns all 16 phases"""
        response = requests.get(f"{BASE_URL}/api/draft-phases")
        assert response.status_code == 200
        data = response.json()
        
        assert len(data) == 16, f"Expected 16 phases, got {len(data)}"
        
        # Verify phase structure
        for phase in data:
            assert "phase" in phase
            assert "action" in phase
            assert "team" in phase
            assert phase['action'] in ['ban', 'pick']
            assert phase['team'] in [1, 2]
        
        print(f"✓ Draft phases endpoint returns {len(data)} phases")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
