from fastapi import FastAPI, APIRouter, HTTPException, WebSocket, WebSocketDisconnect
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, ConfigDict
from typing import List, Optional, Dict, Set
import uuid
from datetime import datetime, timezone
import random
import string
import json

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI()
api_router = APIRouter(prefix="/api")

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, List[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, lobby_code: str):
        await websocket.accept()
        if lobby_code not in self.active_connections:
            self.active_connections[lobby_code] = []
        self.active_connections[lobby_code].append(websocket)

    def disconnect(self, websocket: WebSocket, lobby_code: str):
        if lobby_code in self.active_connections:
            self.active_connections[lobby_code] = [
                ws for ws in self.active_connections[lobby_code] if ws != websocket
            ]
            if not self.active_connections[lobby_code]:
                del self.active_connections[lobby_code]

    async def broadcast(self, lobby_code: str, data: dict):
        if lobby_code not in self.active_connections:
            return
        dead = []
        for ws in self.active_connections[lobby_code]:
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws, lobby_code)

ws_manager = ConnectionManager()

# ABA Character Roster with local cropped images
ABA_CHARACTERS = {
    "One Piece": [
        {"id": "luffy_pts", "name": "Luffy (Pre-TS)"},
        {"id": "zoro_pts", "name": "Zoro (Pre-TS)"},
        {"id": "sanji_pts", "name": "Sanji (Pre-TS)"},
        {"id": "law_pts", "name": "Law (Pre/Post-TS)"},
        {"id": "ace", "name": "Portgas D. Ace"},
        {"id": "luffy_post", "name": "Luffy (Post-TS)"},
        {"id": "zoro_post", "name": "Zoro (Post-TS)"},
        {"id": "sanji_post", "name": "Sanji (Post-TS)"},
        {"id": "kizaru", "name": "Kizaru"},
        {"id": "akainu", "name": "Akainu"},
        {"id": "usopp", "name": "GOD Usopp"},
        {"id": "crocodile", "name": "Crocodile"},
        {"id": "enel", "name": "Enel"},
        {"id": "jinbe", "name": "Jinbe"},
        {"id": "bigmom", "name": "Big Mom"},
        {"id": "rob_lucci", "name": "Rob Lucci"},
        {"id": "aokiji", "name": "Aokiji"},
        {"id": "arlong", "name": "Arlong"},
        {"id": "hancock", "name": "Boa Hancock"},
        {"id": "law_wano", "name": "Law (Wano)"},
        {"id": "whitebeard", "name": "Whitebeard"},
        {"id": "shanks", "name": "Shanks"},
    ],
    "Dragon Ball": [
        {"id": "goku_namek", "name": "Goku (Namek)"},
        {"id": "vegeta_android", "name": "Vegeta (Android)"},
        {"id": "piccolo", "name": "Piccolo"},
        {"id": "krillin", "name": "Krillin"},
        {"id": "gohan_cell", "name": "Gohan (Cell Saga)"},
        {"id": "goku_buu", "name": "Goku (Buu Saga)"},
        {"id": "trunks", "name": "Future Trunks"},
        {"id": "caulifla", "name": "Caulifla"},
        {"id": "vegeta_majin", "name": "Vegeta (Majin)"},
        {"id": "vegito", "name": "Vegito"},
        {"id": "frieza", "name": "Frieza"},
        {"id": "pui_pui", "name": "Pui Pui"},
        {"id": "cell", "name": "Perfect Cell"},
        {"id": "goku_dbs", "name": "Goku (DBS)"},
        {"id": "vegeta_dbs", "name": "Vegeta (DBS)"},
        {"id": "gogeta", "name": "Gogeta"},
        {"id": "bardock", "name": "Bardock"},
        {"id": "jiren", "name": "Jiren"},
        {"id": "broly", "name": "Broly (DBS)"},
        {"id": "goku_black", "name": "Goku Black"},
        {"id": "fused_zamasu", "name": "Fused Zamasu"},
    ],
    "Naruto": [
        {"id": "naruto_p1", "name": "Naruto (Part 1)"},
        {"id": "sasuke_p1", "name": "Sasuke (Part 1)"},
        {"id": "kakashi", "name": "Kakashi"},
        {"id": "rock_lee", "name": "Rock Lee"},
        {"id": "neji", "name": "Neji"},
        {"id": "zabuza", "name": "Zabuza"},
        {"id": "gaara", "name": "Gaara"},
        {"id": "sasuke_ship", "name": "Sasuke (Shippuden)"},
        {"id": "naruto_ship", "name": "Naruto (Shippuden)"},
        {"id": "itachi", "name": "Itachi"},
        {"id": "pain", "name": "Pain"},
        {"id": "might_guy", "name": "Might Guy"},
        {"id": "ay", "name": "Ay (4th Raikage)"},
        {"id": "kisame", "name": "Kisame"},
        {"id": "killer_b", "name": "Killer B"},
        {"id": "sasuke_war", "name": "Sasuke (War Arc)"},
        {"id": "minato", "name": "Minato"},
        {"id": "madara", "name": "Madara"},
        {"id": "shisui", "name": "Shisui"},
        {"id": "tobi", "name": "Tobi"},
    ],
    "Bleach": [
        {"id": "ichigo", "name": "Ichigo"},
        {"id": "rukia", "name": "Rukia"},
        {"id": "shinji", "name": "Shinji"},
        {"id": "byakuya", "name": "Byakuya"},
        {"id": "shunsui", "name": "Shunsui"},
        {"id": "grimmjow", "name": "Grimmjow"},
        {"id": "gin", "name": "Gin"},
        {"id": "starrk", "name": "Coyote Starrk"},
        {"id": "toshiro", "name": "Toshiro"},
        {"id": "ulquiorra", "name": "Ulquiorra"},
        {"id": "ichigo_hollow", "name": "Ichigo (Hollow)"},
        {"id": "yoruichi", "name": "Yoruichi"},
        {"id": "kenpachi", "name": "Kenpachi"},
        {"id": "aizen", "name": "Aizen"},
        {"id": "yhwach", "name": "Yhwach"},
        {"id": "yamamoto", "name": "Yamamoto"},
        {"id": "urahara", "name": "Urahara"},
    ],
    "JoJo": [
        {"id": "jonathan", "name": "Jonathan"},
        {"id": "joseph_bt", "name": "Joseph (BT)"},
        {"id": "jotaro", "name": "Jotaro"},
        {"id": "joseph_sc", "name": "Joseph (SC)"},
        {"id": "josuke", "name": "Josuke"},
        {"id": "giorno", "name": "Giorno"},
        {"id": "kira", "name": "Kira"},
        {"id": "jolyne", "name": "Jolyne"},
        {"id": "pucci", "name": "Pucci"},
        {"id": "hol_horse", "name": "Hol Horse"},
        {"id": "ghiaccio", "name": "Ghiaccio"},
        {"id": "okuyasu", "name": "Okuyasu"},
        {"id": "risotto", "name": "Risotto Nero"},
        {"id": "kars", "name": "Kars"},
        {"id": "weather_report", "name": "Weather Report"},
        {"id": "speedwagon", "name": "Speedwagon"},
        {"id": "dio", "name": "DIO"},
        {"id": "diavolo", "name": "Diavolo"},
    ],
    "Hunter x Hunter": [
        {"id": "gon", "name": "Gon"},
        {"id": "killua", "name": "Killua"},
        {"id": "hisoka", "name": "Hisoka"},
        {"id": "illumi", "name": "Illumi"},
        {"id": "chrollo", "name": "Chrollo"},
        {"id": "kurapika", "name": "Kurapika"},
        {"id": "uvogin", "name": "Uvogin"},
        {"id": "morel", "name": "Morel"},
        {"id": "meruem", "name": "Meruem"},
        {"id": "netero", "name": "Netero"},
    ],
    "Jujutsu Kaisen": [
        {"id": "itadori", "name": "Yuji Itadori"},
        {"id": "gojo", "name": "Satoru Gojo"},
        {"id": "todo", "name": "Aoi Todo"},
        {"id": "sukuna", "name": "Sukuna"},
        {"id": "choso", "name": "Choso"},
        {"id": "geto", "name": "Suguru Geto"},
        {"id": "nanami", "name": "Kento Nanami"},
        {"id": "toji", "name": "Toji Fushiguro"},
        {"id": "jogo", "name": "Jogo"},
    ],
    "My Hero Academia": [
        {"id": "deku", "name": "Deku"},
        {"id": "bakugo", "name": "Bakugo"},
        {"id": "all_might", "name": "All Might"},
        {"id": "todoroki", "name": "Todoroki"},
        {"id": "iida", "name": "Tenya Iida"},
        {"id": "endeavor", "name": "Endeavor"},
        {"id": "lemillion", "name": "Lemillion"},
        {"id": "tokoyami", "name": "Tokoyami"},
        {"id": "vigilante_deku", "name": "Vigilante Deku"},
    ],
    "Fate": [
        {"id": "shirou", "name": "Shirou Emiya"},
        {"id": "saber", "name": "Saber"},
        {"id": "gilgamesh", "name": "Gilgamesh"},
        {"id": "kiritsugu", "name": "Kiritsugu Emiya"},
        {"id": "lancer", "name": "Lancer"},
        {"id": "rider", "name": "Rider (Iskandar)"},
        {"id": "ishtar", "name": "Ishtar"},
        {"id": "mash", "name": "Mash Kyrielight"},
        {"id": "illya", "name": "Illya"},
        {"id": "achilles", "name": "Achilles"},
    ],
    "Fairy Tail": [
        {"id": "natsu", "name": "Natsu"},
        {"id": "gray", "name": "Gray"},
        {"id": "erza", "name": "Erza"},
    ],
    "Chainsaw Man": [
        {"id": "denji", "name": "Denji"},
        {"id": "aki", "name": "Aki"},
        {"id": "power", "name": "Power"},
    ],
    "Demon Slayer": [
        {"id": "tanjiro", "name": "Tanjiro"},
        {"id": "rengoku", "name": "Kyojuro Rengoku"},
        {"id": "tengen", "name": "Tengen Uzui"},
        {"id": "kokushibo", "name": "Kokushibo"},
        {"id": "zenitsu", "name": "Zenitsu"},
    ],
    "SAO": [
        {"id": "kirito", "name": "Kirito"},
        {"id": "asuna", "name": "Asuna"},
        {"id": "sinon", "name": "Sinon"},
    ],
    "One Punch Man": [
        {"id": "saitama", "name": "Saitama"},
        {"id": "tatsumaki", "name": "Tatsumaki"},
        {"id": "metal_bat", "name": "Metal Bat"},
    ],
    "Metal Gear": [
        {"id": "raiden_mgr", "name": "Raiden (MGR)"},
        {"id": "raiden_mgs2", "name": "Raiden (MGS2)"},
        {"id": "snake", "name": "Solid Snake"},
    ],
    "Miscellaneous": [
        {"id": "rikka", "name": "Rikka Takanashi"},
        {"id": "kazuma", "name": "Kazuma Sato"},
        {"id": "afro_samurai", "name": "Afro Samurai"},
        {"id": "chika", "name": "Chika Fujiwara"},
        {"id": "wei_wuxian", "name": "Wei Wuxian"},
        {"id": "ryuko", "name": "Ryuko Matoi"},
        {"id": "guts", "name": "Guts"},
        {"id": "asta", "name": "Asta"},
        {"id": "hiei", "name": "Hiei"},
        {"id": "yusuke", "name": "Yusuke Urameshi"},
        {"id": "accelerator", "name": "Accelerator"},
        {"id": "misaka", "name": "Misaka Mikoto"},
        {"id": "ogun", "name": "Ogun Montgomery"},
        {"id": "sung_jin_woo", "name": "Sung Jin Woo"},
        {"id": "mob", "name": "Mob"},
        {"id": "akira_fudo", "name": "Akira Fudo"},
        {"id": "ragna", "name": "Ragna"},
        {"id": "maka_soul", "name": "Maka & Soul"},
        {"id": "alucard", "name": "Alucard"},
        {"id": "edward_elric", "name": "Edward Elric"},
        {"id": "satsuki", "name": "Satsuki Kiryuin"},
    ],
    "Project Moon": [
        {"id": "roland", "name": "Roland"},
        {"id": "ricardo", "name": "Ricardo"},
    ],
    "Prestige": [
        {"id": "goten_trunks", "name": "Goten and Trunks"},
        {"id": "ohma", "name": "Ohma Tokita"},
        {"id": "super_dummy", "name": "Super Dummy"},
        {"id": "hercule", "name": "Hercule Satan"},
        {"id": "fubuki", "name": "Fubuki"},
        {"id": "ritsu", "name": "Ritsu"},
        {"id": "shadow_dio", "name": "Shadow DIO"},
        {"id": "mr_president", "name": "Mr President"},
        {"id": "deidara", "name": "Deidara"},
    ],
    "Legacy": [
        {"id": "broly_legacy", "name": "Broly (LEGACY)"},
        {"id": "goku_legacy", "name": "Son Goku (LEGACY)"},
        {"id": "gojo_legacy", "name": "Satoru Gojo (LEGACY)"},
    ],
    "Others": [
        {"id": "mr_random", "name": "Mr. Random"},
        {"id": "god", "name": "God"},
        {"id": "jesus", "name": "Jesus"},
        {"id": "2b", "name": "2B"},
        {"id": "shadow_dummy", "name": "Shadow Dummy"},
    ],
}

DRAFT_PHASES = [
    {"phase": 0, "action": "ban", "team": 1, "count": 1},
    {"phase": 1, "action": "ban", "team": 2, "count": 1},
    {"phase": 2, "action": "ban", "team": 1, "count": 1},
    {"phase": 3, "action": "ban", "team": 2, "count": 1},
    {"phase": 4, "action": "pick", "team": 1, "count": 1},
    {"phase": 5, "action": "pick", "team": 2, "count": 1},
    {"phase": 6, "action": "ban", "team": 1, "count": 1},
    {"phase": 7, "action": "ban", "team": 2, "count": 1},
    {"phase": 8, "action": "ban", "team": 1, "count": 1},
    {"phase": 9, "action": "ban", "team": 2, "count": 1},
    {"phase": 10, "action": "pick", "team": 1, "count": 1},
    {"phase": 11, "action": "pick", "team": 2, "count": 1},
    {"phase": 12, "action": "pick", "team": 1, "count": 1},
    {"phase": 13, "action": "pick", "team": 2, "count": 1},
    {"phase": 14, "action": "pick", "team": 1, "count": 1},
    {"phase": 15, "action": "pick", "team": 2, "count": 1},
]

def generate_lobby_code():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

class CharacterInfo(BaseModel):
    id: str
    name: str

class CharacterRoster(BaseModel):
    series: str
    characters: List[CharacterInfo]

class LobbyCreate(BaseModel):
    team1_name: str = "Team 1"
    team2_name: str = "Team 2"

class JoinLobby(BaseModel):
    display_name: str
    team: int

class DraftAction(BaseModel):
    character_id: str
    action_type: str

class LobbyResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    code: str
    team1_name: str
    team2_name: str
    team1_players: List[str]
    team2_players: List[str]
    current_phase: int
    current_action_index: int
    team1_picks: List[str]
    team2_picks: List[str]
    team1_bans: List[str]
    team2_bans: List[str]
    status: str
    created_at: str

@api_router.get("/")
async def root():
    return {"message": "ABA Draft Lobby API"}

@api_router.get("/characters", response_model=List[CharacterRoster])
async def get_characters():
    return [{"series": series, "characters": chars} for series, chars in ABA_CHARACTERS.items()]

@api_router.post("/lobbies", response_model=LobbyResponse)
async def create_lobby(lobby_data: LobbyCreate):
    lobby_id = str(uuid.uuid4())
    code = generate_lobby_code()
    while await db.lobbies.find_one({"code": code}):
        code = generate_lobby_code()
    lobby = {
        "id": lobby_id, "code": code,
        "team1_name": lobby_data.team1_name, "team2_name": lobby_data.team2_name,
        "team1_players": [], "team2_players": [],
        "current_phase": 0, "current_action_index": 0,
        "team1_picks": [], "team2_picks": [],
        "team1_bans": [], "team2_bans": [],
        "status": "waiting",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.lobbies.insert_one(lobby)
    return LobbyResponse(**lobby)

@api_router.post("/lobbies/{code}/join", response_model=LobbyResponse)
async def join_lobby(code: str, join_data: JoinLobby):
    lobby = await db.lobbies.find_one({"code": code.upper()}, {"_id": 0})
    if not lobby:
        raise HTTPException(status_code=404, detail="Lobby not found")
    if lobby["status"] not in ["waiting", "drafting"]:
        raise HTTPException(status_code=400, detail="Cannot join this lobby")
    team_key = f"team{join_data.team}_players"
    if len(lobby[team_key]) >= 4:
        raise HTTPException(status_code=400, detail=f"Team {join_data.team} is full")
    if join_data.display_name in lobby["team1_players"] + lobby["team2_players"]:
        raise HTTPException(status_code=400, detail="Display name already taken")
    lobby[team_key].append(join_data.display_name)
    await db.lobbies.update_one({"code": code.upper()}, {"$set": {team_key: lobby[team_key]}})
    await broadcast_lobby(code, "player_joined")
    return LobbyResponse(**lobby)

@api_router.post("/lobbies/{code}/start", response_model=LobbyResponse)
async def start_draft(code: str):
    lobby = await db.lobbies.find_one({"code": code.upper()}, {"_id": 0})
    if not lobby:
        raise HTTPException(status_code=404, detail="Lobby not found")
    if lobby["status"] != "waiting":
        raise HTTPException(status_code=400, detail="Draft already started or complete")
    await db.lobbies.update_one({"code": code.upper()}, {"$set": {"status": "drafting"}})
    lobby["status"] = "drafting"
    await broadcast_lobby(code, "draft_started")
    return LobbyResponse(**lobby)

@api_router.get("/lobbies/{code}", response_model=LobbyResponse)
async def get_lobby(code: str):
    lobby = await db.lobbies.find_one({"code": code.upper()}, {"_id": 0})
    if not lobby:
        raise HTTPException(status_code=404, detail="Lobby not found")
    return LobbyResponse(**lobby)

@api_router.post("/lobbies/{code}/action", response_model=LobbyResponse)
async def draft_action(code: str, action: DraftAction):
    lobby = await db.lobbies.find_one({"code": code.upper()}, {"_id": 0})
    if not lobby:
        raise HTTPException(status_code=404, detail="Lobby not found")
    if lobby["status"] == "complete":
        raise HTTPException(status_code=400, detail="Draft is already complete")
    if lobby["status"] != "drafting":
        raise HTTPException(status_code=400, detail="Draft has not started")
    current_phase = lobby["current_phase"]
    if current_phase >= len(DRAFT_PHASES):
        raise HTTPException(status_code=400, detail="Draft is complete")
    phase_info = DRAFT_PHASES[current_phase]
    if action.action_type != phase_info["action"]:
        raise HTTPException(status_code=400, detail=f"Expected {phase_info['action']}, got {action.action_type}")
    all_picks = lobby["team1_picks"] + lobby["team2_picks"]
    all_bans = lobby["team1_bans"] + lobby["team2_bans"]
    if action.character_id in all_picks or action.character_id in all_bans:
        raise HTTPException(status_code=400, detail="Character already selected")
    update = {}
    team = phase_info["team"]
    if action.action_type == "pick":
        if team == 1:
            lobby["team1_picks"].append(action.character_id)
            update["team1_picks"] = lobby["team1_picks"]
        else:
            lobby["team2_picks"].append(action.character_id)
            update["team2_picks"] = lobby["team2_picks"]
    else:
        if team == 1:
            lobby["team1_bans"].append(action.character_id)
            update["team1_bans"] = lobby["team1_bans"]
        else:
            lobby["team2_bans"].append(action.character_id)
            update["team2_bans"] = lobby["team2_bans"]
    new_phase = current_phase + 1
    update["current_phase"] = new_phase
    update["current_action_index"] = 0
    if new_phase >= len(DRAFT_PHASES):
        update["status"] = "complete"
    await db.lobbies.update_one({"code": code.upper()}, {"$set": update})
    lobby.update(update)
    event = "ban" if action.action_type == "ban" else "pick"
    if lobby.get("status") == "complete":
        event = "draft_complete"
    await broadcast_lobby(code, event)
    return LobbyResponse(**lobby)

@api_router.post("/lobbies/{code}/reset", response_model=LobbyResponse)
async def reset_draft(code: str):
    lobby = await db.lobbies.find_one({"code": code.upper()}, {"_id": 0})
    if not lobby:
        raise HTTPException(status_code=404, detail="Lobby not found")
    update = {"current_phase": 0, "current_action_index": 0, "team1_picks": [], "team2_picks": [], "team1_bans": [], "team2_bans": [], "status": "waiting"}
    await db.lobbies.update_one({"code": code.upper()}, {"$set": update})
    lobby.update(update)
    await broadcast_lobby(code, "draft_reset")
    return LobbyResponse(**lobby)

async def broadcast_lobby(code: str, event_type: str = "update"):
    lobby = await db.lobbies.find_one({"code": code.upper()}, {"_id": 0})
    if lobby:
        lobby_resp = LobbyResponse(**lobby)
        await ws_manager.broadcast(code.upper(), {
            "type": event_type,
            "lobby": lobby_resp.model_dump()
        })

@api_router.get("/draft-phases")
async def get_draft_phases():
    return DRAFT_PHASES

@app.websocket("/api/ws/{code}")
async def websocket_endpoint(websocket: WebSocket, code: str):
    code = code.upper()
    await ws_manager.connect(websocket, code)
    try:
        # Send current state on connect
        lobby = await db.lobbies.find_one({"code": code}, {"_id": 0})
        if lobby:
            lobby_resp = LobbyResponse(**lobby)
            await websocket.send_json({"type": "connected", "lobby": lobby_resp.model_dump()})
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket, code)
    except Exception:
        ws_manager.disconnect(websocket, code)

app.include_router(api_router)
app.add_middleware(CORSMiddleware, allow_credentials=True, allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','), allow_methods=["*"], allow_headers=["*"])
logging.basicConfig(level=logging.INFO)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
